/*
 Name : Suryansh Chauhan
 Roll No : 54
 Section : I1 / Course : B-Tech CSE

 Q2. Power Calculator with Exception Handling: Create a class called MyCalculator with a method power(int n, int p) that calculates n raised to the power p (i.e., n^p).

Method Requirements:
1. If either n or p is negative, the method should throw an exception with the message:
“n or p should not be negative.”
2. If both n and p are zero, the method should throw an exception with the message:
“n and p should not be zero.”
3. Otherwise, return the value of n^p.

Input Format:
The input consists of multiple lines. Each pair of lines contains two integers: the first line has the value of n, and the second line has the value of p. The input is read using the Scanner class and continues until all input is processed using hasNext().

Output Format:
1. Print the result of n^p if valid.
2. Otherwise, print the appropriate exception message.
 */

 // SOURCE CODE:

 import java.util.Scanner;

 class MyCalculator {
     public long power(int n, int p) throws Exception {
         if (n < 0 || p < 0) {
             throw new Exception("n or p should not be negative.");
         }
         if (n == 0 && p == 0) {
             throw new Exception("n and p should not be zero.");
         }
         return (long) Math.pow(n, p);
     }
 }
 
 public class Question2 {
     public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         MyCalculator myCalc = new MyCalculator();
         
         while (sc.hasNext()) {
             int n = sc.nextInt();
             int p = sc.nextInt();
             try {
                 System.out.println(myCalc.power(n, p));
             } catch (Exception e) {
                 System.out.println(e.getMessage());
             }
         }
         sc.close();
     }
 }
 
