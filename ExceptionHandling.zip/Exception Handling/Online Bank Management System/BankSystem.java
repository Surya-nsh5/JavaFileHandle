/*
 Name : Suryansh Chauhan
 Roll No : 54
 Section : I1 / Course : B-Tech CSE
 
Project Summary:
Design and implement a simple Online Bank Account Management System using Java that demonstrates robust exception handling. The system should allow users to create accounts, deposit and withdraw money, and view their account balance. It must handle different runtime issues such as invalid input, negative deposit amounts, and withdrawal attempts exceeding the available balance. To manage these scenarios, use Java’s exception handling features including try, catch, finally, multiple catch blocks, throw, throws, and user-defined exceptions. The goal is to ensure the application behaves reliably and gracefully under error conditions, promoting strong programming practices related to exception management.

Create a simple command-line bank account management system where users can:

1.Create an account
2.Deposit money
3.Withdraw money
4.View balance

The program should handle various exception scenarios using:

1.User-defined exceptions for custom error situations
2.try-catch-finally for safe execution
3.Multiple catch blocks for different exception types
4.throw and throws to handle and propagate errors
 */

// SOURCE CODE:

import java.util.InputMismatchException;
import java.util.Scanner;

class InvalidAmountException extends Exception {
    public InvalidAmountException(String message) {
        super(message);
    }
}

class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

class BankAccount {
    private String accountHolderName;
    private double balance;

    public BankAccount(String accountHolderName) {
        this.accountHolderName = accountHolderName;
        this.balance = 0.0;
    }

    public void deposit(double amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Deposit amount must be positive.");
        }
        balance += amount;
        System.out.println("Successfully deposited: " + amount);
    }

    public void withdraw(double amount) throws InvalidAmountException, InsufficientFundsException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount must be positive.");
        }
        if (amount > balance) {
            throw new InsufficientFundsException("Insufficient amount. Available balance: " + balance);
        }
        balance -= amount;
        System.out.println("Successfully withdrew: " + amount);
    }

    public void viewBalance() {
        System.out.println("Current balance: " + balance);
    }
}

public class BankSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankAccount account = null;

        try {
            System.out.print("Enter Account Holder's Name: ");
            String name = scanner.nextLine();
            account = new BankAccount(name);

            while (true) {
                System.out.println("\n---- Online Bank Account Management ----");
                System.out.println("1. Deposit Money");
                System.out.println("2. Withdraw Money");
                System.out.println("3. View Balance");
                System.out.println("4. Exit");
                System.out.print("Choose an option (1-4): ");

                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter amount to deposit: ");
                        double depositAmount = scanner.nextDouble();
                        account.deposit(depositAmount);
                        break;

                    case 2:
                        System.out.print("Enter amount to withdraw: ");
                        double withdrawAmount = scanner.nextDouble();
                        account.withdraw(withdrawAmount);
                        break;

                    case 3:
                        account.viewBalance();
                        break;

                    case 4:
                        System.out.println("Exited!");
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice.");
                }
            }

        } catch (InputMismatchException e) {
            System.out.println("Input error: Please enter numeric values where required.");
        } catch (InvalidAmountException | InsufficientFundsException e) {
            System.out.println("Transaction error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error occurred: " + e.getMessage());
        } finally {
            scanner.close();
            System.out.println("Scanner closed.");
        }
    }
}
