/*
 Name : Suryansh Chauhan
 Roll No : 54
 Section : I1 / Course : B-Tech CSE
 
Q1. Write a Java program to accept and print employee details at runtime. The details should include Employee ID, Name, and Department ID.

The program must validate the input data and raise appropriate exceptions if any of the following conditions are not met:

The first letter of the employee name should be a capital letter.
The employee ID should be an integer between 2001 and 5001 (inclusive).
The department ID should be an integer between 1 and 5 (inclusive).
If any of the above conditions fail, the program should raise a specific exception with a clear message. Otherwise, it should display the entered employee details normally.
 */

// SOURCE CODE:

import java.util.Scanner;

class InvalidEmployeeNameException extends Exception {
    public InvalidEmployeeNameException(String message) {
        super(message);
    }
}

class InvalidEmployeeIdException extends Exception {
    public InvalidEmployeeIdException(String message) {
        super(message);
    }
}

class InvalidDepartmentIdException extends Exception {
    public InvalidDepartmentIdException(String message) {
        super(message);
    }
}

public class Question1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter Employee ID (2001-5001): ");
            int empId = sc.nextInt();
            sc.nextLine(); 

            if (empId < 2001 || empId > 5001) {
                throw new InvalidEmployeeIdException("Employee ID must be btw 2001 & 5001.");
            }

            System.out.print("Enter Employee Name (First letter capital): ");
            String name = sc.nextLine();

            if (name.isEmpty() || !Character.isUpperCase(name.charAt(0))) {
                throw new InvalidEmployeeNameException("Employee name must start with a capital letter.");
            }

            System.out.print("Enter Department ID (1-5): ");
            int deptId = sc.nextInt();

            if (deptId < 1 || deptId > 5) {
                throw new InvalidDepartmentIdException("Department ID must be between 1 and 5.");
            }

            System.out.println("\n--- Employee Details ---");
            System.out.println("Employee ID: " + empId);
            System.out.println("Employee Name: " + name);
            System.out.println("Department ID: " + deptId);

        } catch (InvalidEmployeeNameException | InvalidEmployeeIdException | InvalidDepartmentIdException e) {
            System.out.println("Input Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
