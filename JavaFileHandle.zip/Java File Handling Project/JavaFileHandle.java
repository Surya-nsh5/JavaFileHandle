/*
Name : Suryansh Chauhan
Sec : I1 / Roll No : 54
Course : B-Tech (CSE) / Sem : 4th

-------------------Project Overview:-------------------------

Develop a Java Notes Manager that allows users to create, update, and analyze text-based notes efficiently. This application will enable users to:

1. Create a new Java note “JavaFile1.txt” (enter the given text from the console and save it to this file)

Java is an object-oriented programming language.
It supports encapsulation, inheritance, and polymorphism.
File handling in Java allows for efficient reading and searching of text.
Keep learning and mastering Java!

2. Display the existing Java note (read and display file content on the console).
3. Create another Java note “JavaFile2.txt” and (enter the given text from the console and save it to this file)
This is the first line in this JavaFile2.txt file.
4. Read the content of Java note “JavaFile1.txt” and copy it to “JavaFile2.txt” using file steams. (Keep the previous text intact and add it from the next line)
5. Analyze the “JavaFile1.txt” note, providing:
Total number of characters?
Total number of lines?
Total number of words?
6. Search for the word “polymorphism” in “JavaFile1.txt” and print the line number where it appears and also find the total occurrences of this word in this file.
  Hint:
Read each line using ‘fileobj.readLine()’ until ‘null’.
Check if ‘line.contains(wordToFind)’.
Increment a counter to track the line number when found.
*/

import java.io.*;
import java.util.Scanner;

public class JavaFileHandle {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // ------- Create JavaFile1.txt --------
        String file1 = "JavaFile1.txt";
        String file2 = "JavaFile2.txt";
        String file1Content = """
            Java is an object-oriented programming language.
            It supports encapsulation, inheritance, and polymorphism.
            File handling in Java allows for efficient reading and searching of text.
            Keep learning and mastering Java!
            """;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file1))) {
            writer.write(file1Content);
            System.out.println("-------JavaFile1.txt created.-------\n");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // -------- Display JavaFile1.txt content ---------
        System.out.println("Contents of JavaFile1.txt:");
        try (BufferedReader reader = new BufferedReader(new FileReader(file1))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            System.out.println();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // --------- Create JavaFile2.txt with one line ---------
        System.out.println("Enter content for JavaFile2.txt:");
        String userInput = scanner.nextLine();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file2))) {
            writer.write(userInput);
            writer.newLine();
            System.out.println("-------JavaFile2.txt created with user input.-------\n");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // -------- Copy JavaFile1.txt to JavaFile2.txt (append mode) -----------
        try (
            BufferedReader reader = new BufferedReader(new FileReader(file1));
            BufferedWriter writer = new BufferedWriter(new FileWriter(file2, true))
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Contents of JavaFile1.txt appended to JavaFile2.txt.\n");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // --------- Analyze JavaFile1.txt -----------
        System.out.println("-------Counting Line, Words, Char of JavaFile1.txt--------");
        int lineCount = 0;
        int wordCount = 0;
        int charCount = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(file1))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lineCount++;
                wordCount += line.split("\\s+").length;
                charCount += line.length();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Total Characters: " + charCount);
        System.out.println("Total Words: " + wordCount);
        System.out.println("Total Lines: " + lineCount + "\n");

        // --------- Search for "polymorphism" in JavaFile1.txt ------------
        String wordToFind = "polymorphism";
        int searchLineNum = 0;
        int totalOccurrences = 0;

        System.out.println("Searching for word: \"" + wordToFind + "\"");
        try (BufferedReader reader = new BufferedReader(new FileReader(file1))) {
            String line;
            int currentLineNum = 1;
            while ((line = reader.readLine()) != null) {
                if (line.toLowerCase().contains(wordToFind)) {
                    System.out.println("Found at line: " + currentLineNum);
                    totalOccurrences += countOccurrences(line.toLowerCase(), wordToFind);
                }
                currentLineNum++;
            }
            System.out.println("Total Occurrences: " + totalOccurrences);
        } catch (IOException e) {
            e.printStackTrace();
        }

        scanner.close();
    }

    private static int countOccurrences(String line, String word) {
        int count = 0;
        int index = 0;
        while ((index = line.indexOf(word, index)) != -1) {
            count++;
            index += word.length();
        }
        return count;
    }
}
