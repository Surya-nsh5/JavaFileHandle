/*
    Name - Suryansh Chauhan
    Roll No - 54 / Sem - 4th
    Section - I1 /Course - B-Tech(CSE)
    PROJECT-4. Create a GUI project using MouseMotionAdapter class to draw shapes using clicks and motion of the mouse.
 */

// SOURCE CODE :-

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Project4 extends MouseMotionAdapter {
    JFrame f;

    public static void main(String[] args) {
        new Project4();
    }

    Project4() {
        f = new JFrame("Project 4 - Draw with Mouse");
        f.addMouseMotionListener(this);
        f.setSize(500, 500);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void mouseDragged(MouseEvent e) {
        Graphics g = f.getGraphics();
        g.setColor(Color.RED);
        g.fillRect(e.getX(), e.getY(), 5, 5);
    }
}
