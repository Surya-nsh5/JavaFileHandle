/*
    Name - Suryansh Chauhan
    Roll No - 54 / Sem - 4th
    Section - I1 /Course - B-Tech(CSE)
    PROJECT-3. Create a GUI project using JFrame and Canvas classes to draw the given figure.
 */

// SOURCE CODE :-

import java.awt.*;
import javax.swing.*;

public class Project3 extends Canvas {

    public static void main(String[] args) {
        Project3 obj = new Project3();
        JFrame jf = new JFrame("Project 3 - Drawing Figure");
        jf.add(obj);
        jf.setSize(600, 300);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        g.setColor(Color.YELLOW);
        g.fillRect(100, 120, 300, 60);
        g.fillRect(170, 90, 160, 40);

        g.setColor(Color.CYAN);
        g.fillRect(180, 95, 60, 30);
        g.fillRect(250, 95, 60, 30);

        g.setColor(Color.BLACK);
        g.fillOval(130, 170, 40, 40);
        g.fillOval(330, 170, 40, 40);

        g.setColor(Color.DARK_GRAY);
        g.drawRect(100, 120, 300, 60);
        g.drawRect(170, 90, 160, 40);
        g.drawOval(130, 170, 40, 40);
        g.drawOval(330, 170, 40, 40);
    }
}

