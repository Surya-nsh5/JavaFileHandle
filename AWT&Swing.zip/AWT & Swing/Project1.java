/*
    Name - Suryansh Chauhan
    Roll No - 54 / Sem - 4th
    Section - I1 /Course - B-Tech(CSE)
    PROJECT-1. Create a project, in which you take two inputs from a user and when the user clicks on “+” "-" "*" "/" button the result will be shown on the screen.
 */

// SOURCE CODE :-

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Project1 extends JFrame {

    JTextField t1 = new JTextField(5);
    JTextField t2 = new JTextField(5);

    JButton addButton = new JButton("+");
    JButton subButton = new JButton("-");
    JButton mulButton = new JButton("*");
    JButton divButton = new JButton("/");

    JLabel resultLabel = new JLabel("Output");

    public Project1() {
        setTitle("Project 1 - Calculator");
        setLayout(new FlowLayout());
        setSize(550, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        add(t1);
        add(t2);
        add(addButton);
        add(subButton);
        add(mulButton);
        add(divButton);
        add(resultLabel);

        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String s1 = t1.getText();
                    String s2 = t2.getText();

                    int a = Integer.parseInt(s1);
                    int b = Integer.parseInt(s2);
                    int result = 0;

                    if (e.getSource() == addButton) {
                        result = a + b;
                    } else if (e.getSource() == subButton) {
                        result = a - b;
                    } else if (e.getSource() == mulButton) {
                        result = a * b;
                    } else if (e.getSource() == divButton) {
                        if (b == 0) {
                            resultLabel.setText("Cannot divide by 0");
                            return;
                        }
                        result = a / b;
                    }

                    resultLabel.setText("Result: " + result);
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid Input");
                }
            }
        };

        addButton.addActionListener(al);
        subButton.addActionListener(al);
        mulButton.addActionListener(al);
        divButton.addActionListener(al);
    }

    public static void main(String[] args) {
        new Project1().setVisible(true);
    }
}
