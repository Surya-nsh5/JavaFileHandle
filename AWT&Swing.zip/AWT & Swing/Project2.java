/*
    Name - Suryansh Chauhan
    Roll No - 54 / Sem - 4th
    Section - I1 /Course - B-Tech(CSE)
    PROJECT-2. Create a project that takes the user’s name as input and provides two radio buttons to select if the user is male or female (ensuring only one can be selected). Additionally, provide two checkboxes to ask if the user likes coffee or tea (both options can be selected). When the user clicks the “Submit Details” button, your application must display a message with all the information, such as “Mr. Amit likes coffee, likes tea.”
 */

// SOURCE CODE :-

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Project2 extends JFrame {

    JTextField nameField = new JTextField(15);

    JRadioButton maleButton = new JRadioButton("Male");
    JRadioButton femaleButton = new JRadioButton("Female");
    ButtonGroup genderGroup = new ButtonGroup();

    JCheckBox coffeeBox = new JCheckBox("Likes Coffee");
    JCheckBox teaBox = new JCheckBox("Likes Tea");

    JButton submitButton = new JButton("Submit Details");

    JLabel outputLabel = new JLabel("Details will appear here : ");

    public Project2() {
        setTitle("Project 2 - User Details");
        setLayout(new FlowLayout());
        setSize(800, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        add(new JLabel("Enter your name:"));
        add(nameField);

        genderGroup.add(maleButton);
        genderGroup.add(femaleButton);
        add(maleButton);
        add(femaleButton);

        add(coffeeBox);
        add(teaBox);

        add(submitButton);
        add(outputLabel);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String title = "";
                StringBuilder preferences = new StringBuilder();

                if (maleButton.isSelected()) {
                    title = "Mr. ";
                } else if (femaleButton.isSelected()) {
                    title = "Ms. ";
                } else {
                    outputLabel.setText("Please select gender.");
                    return;
                }

                if (name.isEmpty()) {
                    outputLabel.setText("Please enter a name.");
                    return;
                }

                preferences.append(title).append(name);

                if (coffeeBox.isSelected()) {
                    preferences.append(" likes coffee");
                }

                if (teaBox.isSelected()) {
                    if (coffeeBox.isSelected()) {
                        preferences.append(", likes tea");
                    } else {
                        preferences.append(" likes tea");
                    }
                }

                if (!coffeeBox.isSelected() && !teaBox.isSelected()) {
                    preferences.append(" has no drink preference");
                }

                preferences.append(".");

                outputLabel.setText(preferences.toString());
            }
        });
    }

    public static void main(String[] args) {
        new Project2().setVisible(true);
    }
}
